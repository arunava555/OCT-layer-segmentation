CRF_OCT_SEG v1.

Author: Arunava Chakravarty
Supervisor: Prof. Jayanthi Sivaswamy
Center for Visual Information Technology, IIIT-Hyderabad (https://cvit.iiit.ac.in/projects/mip/)
-----------------------------------------------------------------------------------------------------------------------------------
This code is a Matlab implementation of our method to segment layer boundaries in retinal OCT images and based on the following publications.

[1] Arunava Chakravarty and Jayanthi Sivaswamy, "A Supervised Joint Multi-layer Segmentation Framework for Retinal Optical Coherence Tomography Images using Conditional Random Field", Computer Methods and Programs in Biomedicine,2018.
[2] Chakravarty, Arunava, and Jayanthi Sivaswamy. "End-to-End Learning of 
a Conditional Random Field for Intra-retinal Layer Segmentation in Optical 
Coherence Tomography." Medical Image Understanding and Analysis, 
pp. 3-14. Springer, Cham, 2017.


The test code along with the trained models for all experiments in the above paper is being released publicly to allow other researchers to develop, compare and benchmark their algorithms. This code is not clinically approved and released for non-commerical research purposes only.

The original code used in the experiments reported in the paper has been re-arranged and currently only the test part of the code and the learnt models are being made available. Also, the unflatenning code used in preprocessing has been modified from the one used in our experiments in the paper. This code is not optimal in terms of memory and computational efficiency, but only a prototype used to demonstrate our method.
-----------------------------------------------------------------------------------------------------------------------------------
The four folders contain codes which run on different datasets/pathologies. Run the "main_script.m" in each folder.

------------------------------------------------------------------------------------------------------------------------------------
Other relevant publications

The example B-scan in each folder is taken from public datasets which are cited below:

[2]S. J. Chiu, X. T. Li, P. Nicholas, C. A. Toth, J. A. Izatt, S. Farsiu, Au-
tomatic segmentation of seven retinal layers in sdoct images congruent
with expert manual segmentation, Optics Express 18 (2010) 19413–
19428.

[3] J. Tian, B. Varga, G. M. Somfai, W.-H. Lee, W. E. Smiddy, D. C.
DeBuc, Real-time automatic segmentation of optical coherence tomog-
raphy volume data of the macular region, PloS One 10 (2015) e0133908.

[4] S. J. Chiu, J. A. Izatt, R. V. O’Connell, K. P. Winter, C. A. Toth,
S. Farsiu, Validated automatic segmentation of amd pathology includ-
ing drusen and geographic atrophy in sd-oct images, Investigative Oph-
thalmology & Visual Science 53 (2012) 53–61.

[5] S. J. Chiu, M. J. Allingham, P. S. Mettu, S. W. Cousins, J. A. Izatt,
S. Farsiu, Kernel regression based segmentation of optical coherence
tomography images with diabetic macular edema, Biomedical Optics
Express 6 (2015) 1172–1194.

 The TRW-S has been used for CRF inference:

[6] V. Kolmogorov, Convergent tree-reweighted message passing for energy
minimization, IEEE Transactions on Pattern Analysis and Machine
Intelligence 28 (2006) 1568–1583.

The SRAD has been used for denoising,
[7] Y. Yu, S. T. Acton, Speckle reducing anisotropic diffusion, IEEE Trans-
actions on Image Processing 11 (2002) 1260–1270.

















