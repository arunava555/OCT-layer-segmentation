function [yhat]=comp_res(img,w)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
load('dflt.mat','dflt_ht','thk');
inc=4;
sz=size(img);
sz(2)=sz(2)/inc;
% STep1: Sampling of the image 4 pixels apart 
res=zeros(188,600);
res(:,1:4:end)=1;
idx=find(res==1);
clear res

%Step2: Extract patches
sz99=19;
    pad_img = padarray(img, floor([sz99 sz99]/2), 'replicate');
    X=im2col(pad_img,[sz99 sz99],'sliding');
    X=X(:,idx);
    


load norm_range.mat
w=w./dd';

Y=X;


w1=w(1:size(X,1)*8);
w2=w(size(X,1)*8+1:size(X,1)*8+(size(Y,1)+1)*7);
w3=w(size(X,1)*8+(size(Y,1)+1)*7+1:end);

d1=size(X,1)*8;
d2=(size(Y,1)+1)*7;

    data_term=[];
%% Step 3: Create data term, pairwise term: intra and inter
% data terms
w1=reshape(w1,[d1/8 8]);
score=w1'*X;
for l=1:8
   % convolution result with lth filter
   tmp=score(l,:);
   tmp=reshape(tmp,sz);
   % Crop the region where we have hard-limited lth boundary
   tmp=tmp(dflt_ht(l)+1:dflt_ht(l)+thk(l),:);
 
   %% Graph cut
   % Data Term #L by #N
   % each col of tmp is the -data term for a node in layer L, 
   % Data Term data{N}=L by 1 array
   data_term=[data_term; num2cell(-1.*tmp,1)'];% each col of tmp is the -data term for a node in layer L
end


%% Inter-layer pairwise  term and graph edges 
% graph edges:(l,n): Data term is arranged as:
% (1,1),(1,2)...(1,N),(2,1),(2,2)... (2,N)
%(l,n) has edge with (l+1,n): in linear index:j will be nbr of j+N, here N
%is sz(2)
load inter_stats.mat
i=1:(7*sz(2));  % all except nodes of last layer
j=i+sz(2); % corresponding nodes in the next layer
graph=[i;j];
clear i j


%
w2=reshape(w2,[d2/7 7]);
w2b=w2(end,:);
w2=w2(1:end-1,:);
inter_score=w2'*X;
for l=1:7
    tmp7=inter_score(l,:);
   tmp7=reshape(tmp7,sz);
    [tmp_pair]=inter_layer(dflt_ht(l),dflt_ht(l+1),tmp7,d_inter_mn(l,:),d_inter_std(l,:),thk(l),thk(l+1),w2b(l),d_inter_min(l,:),d_inter_max(l,:)); 

   
    % - as we need to minimize                                    
    tmp=squeeze(num2cell(-1.*tmp_pair, [1 2]));
	% now linearize
    if l==1
        pair_inter=cellfun(@(x) x(:), tmp, 'un',0);
    else
        pair_inter=[pair_inter; cellfun(@(x) x(:), tmp, 'un',0)];
    end
end
%% Intra-layer

% Graph
graph_new=[];
for l=1:8
    % node in layer l: (l-1)*sz(2)+1:l*sz(2)
    i=(((l-1)*sz(2))+1):(l*sz(2))-1;
    j=(((l-1)*sz(2))+2):(l*sz(2));
    graph_new=[graph_new [i;j]];
end

    
   % load([precomp_dir nm],'tmp1','grd','idx','idx99');
   [tmp1, grd, idx, idx99]=precomp(X, sz,thk,dflt_ht);
  

for l=1:8

    tmp_pair=zeros(thk(l),thk(l),sz(2)-1);
   tmp=w3((2*l)-1)*tmp1{l}+(w3(2*l).*grd{l})'+idx99{l}';
   tmp_pair(idx{l})=tmp;
   
      
   
    tmp=squeeze(num2cell(-1.*tmp_pair, [1 2]));
    % now linearize
    if l==1
        pair_intra=cellfun(@(x) x(:), tmp, 'un',0);
    else
        pair_intra=[pair_intra; cellfun(@(x) x(:), tmp, 'un',0)];
    end
   clear tmp_pair mn sigma 
end
clear tmp1 grd idx idx99


%% Run TRWS
graph=[graph graph_new];
pair=[pair_inter;pair_intra];
clearvars -except data_term pair graph sz

options = [];
options.num_max_iter = 175;
mu_unary_trws = mex_trws(data_term, pair, double(graph-1), options);
gcut=cell2mat(cellfun(@(x) find(x==max(x)), mu_unary_trws, 'un',0));

yhat=reshape(gcut,sz(2),8)';

