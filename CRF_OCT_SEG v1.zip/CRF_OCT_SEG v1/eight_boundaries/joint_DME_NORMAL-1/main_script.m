clear all
clc
addpath(genpath('/home/arunava/CRF_OCT_segment/external_toolbox/'))

% load the input B-scan
load('Subject_07_1.mat','img');
f=img;% save a copy

%% Preprocessing
[shift]=my_flatten(img);
[ img, mnx, mxx,flat_sz ,crop_sz ] = preprocess( img,17, shift );
img=intensity_standardize(img);

%% Segmentation
load(['model_fold1.mat']);% 5 mat files were learnt, one for each fold
res=comp_res(img,wAvg);

%% Reverse the preprocessing to bring back to original coordinate space
%bias=[0.04 -0.1 -0.04 0.2 -0.1 -0.05 0 -0.4638]; % better suited for healthy
bias=[0.175 0 -0.1 0.7 1 0.23 -0.5559 0.3311]; %better suited for DME
res=reverse_preprocessing(res, bias,img, mnx, mxx,flat_sz ,crop_sz,shift);


 r=my_visualize(f,res);
 figure, imshow(r,[])