clear all
clc
addpath(genpath('/home/arunava/CRF_OCT_segment/external_toolbox/'))

% load the input B-scan
load('No1_Subject8_8.mat','img');
f=img;% save a copy


%% Preprocessing
[shift]=my_flatten(img);
[ img, mnx, mxx,flat_sz ,crop_sz ] = preprocess( img,17, shift );
img=intensity_standardize(img);

%% Segmentation
load('model1.mat');
w=model.w;
res=comp_res(img,w);

%% Reverse the preprocessing to bring back to original coordinate space
bias=[ 0.5084  0   -0.25   0.83  0.20  .9 -0.33   -1.7];
res=reverse_preprocessing(res, bias,img, mnx, mxx,flat_sz ,crop_sz,shift);


 r=my_visualize(f,res);
 figure, imshow(r,[])