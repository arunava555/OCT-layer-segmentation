function [mask] = my_flatten2( img,d )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
img1=img;

 mask=zeros(size(img));
 for col=1:size(img1,2)
      tmp_col=img1(:,col);
      sh=d(col);
                                                               
      tmp_col=circshift(tmp_col,[-sh 0]);
      mask(:,col)=tmp_col;

     
   
   end
  
 
end

