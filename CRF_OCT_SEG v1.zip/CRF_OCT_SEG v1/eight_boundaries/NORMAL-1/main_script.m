clear all
clc
addpath(genpath('/home/arunava/CRF_OCT_segment/external_toolbox/'))

% load the input B-scan
load('Subject_04_4.mat','img');
f=img;% save a copy

tic
%% Preprocessing
[shift]=my_flatten(img);
[ img, mnx, mxx,flat_sz ,crop_sz ] = preprocess( img,17, shift );
img=intensity_standardize(img);

%% Segmentation
load('model1.mat');% 5 models are provided trained on the 5 folds
w=model.w;
res=comp_res(img,w);

%% Reverse the preprocessing to bring back to original coordinate space
bias=[0 0 0 0 0 0 0 0];
res=reverse_preprocessing(res, bias,img, mnx, mxx,flat_sz ,crop_sz,shift);
toc

 r=my_visualize(f,res);
 figure, imshow(r,[])