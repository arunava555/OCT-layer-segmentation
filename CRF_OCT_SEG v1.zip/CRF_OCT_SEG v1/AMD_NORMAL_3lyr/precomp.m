function  [tmp1, grd, idx, idx99]=precomp(X, sz,thk,dflt_ht)
load intra_stats.mat
   tmpX=uint8(round(X.*255));
   tmpX=histc( tmpX, 0:255 );
   tmpX=bsxfun(@rdivide,tmpX ,sum(tmpX));
   clear X
   
for l=1:3

  
   [i,j,n]=meshgrid(1:thk(l),1:thk(l),1:(sz(2)-1));
   i=int16(i(:));j=int16(j(:));n=int16(n(:));
   i=i+dflt_ht(l);
   j=j+dflt_ht(l);
   
   grd1=abs(j-i);
   grd1=double(grd1);
   
   mn=d_intra_mn(l,:);
   sigma=d_intra_std(l,:);
   grd1=exp(- 0.5 * (((grd1' - mn(n)) ./ sigma(n)) .^ 2))';
   grd{l}=grd1;
   

   index=find(abs(j-i)>max(d_intra_max(1,:)));
   index1=zeros(size(grd1));
   index1(index)=-999999;
   idx99{l}=index1; 
   clear index  index1 grd1
   
   %
   idx_lt=sub2ind(sz,i,n);
   idx_rt=sub2ind(sz,j,(n+1));
   

   h_lt=tmpX(:,idx_lt);
   h_rt=tmpX(:,idx_rt);
   tmp1{l}=sum(min(h_lt,h_rt)); 

   clear h_lt h_rt  mn sigma idx_lt idx_rt
     idx{l}=sub2ind([thk(l),thk(l),sz(2)-1],(i-dflt_ht(l)),(j-dflt_ht(l)),n);
     clear i j n
 
   end
 
end


