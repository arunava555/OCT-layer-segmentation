function [ img, mnx, mxx ,flat_sz ,crop_sz ] = preprocess( img,niter, shift)


%% Flatten image
[flat_img] = my_flatten2( img, shift);   
flat_sz=size(flat_img);

%% Get Mask
[mnx, mxx]=my_mask(flat_img);
%
%% denoising
top=min(mxx+50, size(flat_img,1)-2);
ht=size(flat_img,1)-top;
left=5;
width=size(flat_img,2)-10;


rect = [left top  width ht]; 
[J,rect] = SRAD(flat_img,niter,0.5,rect);
flat_img=medfilt2(J,[5 5]);
%}
%% CROP IMAGE
img=flat_img(mnx:mxx,:);
crop_sz=size(img);


%% RESIZE
 
 img=imresize(img,[188 600],'bicubic');
 
end

