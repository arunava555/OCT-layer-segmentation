function [ tmp] = my_visualize( images,manualLayers1 )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
 clr{1}=[255 0 0];% Red
 clr{2}=[0 255 0];
 clr{3}=[0 0 255];
 clr{4}=[255 255 0];
 clr{5}=[0 255 255];
 clr{6}=[255 0 255];
 clr{7}=[255 0 144]; % magenta
 clr{8}=[75 0 130]; % indigo
 
 images=double(images);
  images=images-min(images(:));
    images=images./max(images(:));
    images=images.*255;
    images=uint8(images);
    
    res1=images;
    res2=images;
    res3=images;
    
   
        for layers=1:size(manualLayers1,1) % 
            % i,j,k-> k is the slice no, j is the column no, i is layer to
            %be segmented, seg(i,j,k)=the ht of ith layer in jth col in kth slice
            x=manualLayers1(layers,:);
          
         
            x=round(x);
              x(find(x<=0))=1;
             
            y=1:length(x);
            
              x=[x-1 x x+1];
              y=[y y y ];
            
       idx=find(x<1);x(idx)=1;
       idx=find(y<1);y(idx)=1;
       
       idx=find(x>size(res1,1));x(idx)=size(res1,1);
       idx=find(y>size(res1,2));y(idx)=size(res1,2);
       
            
            idx=sub2ind(size(images),x,y);
            res1(idx)=clr{layers}(1);res2(idx)=clr{layers}(2);res3(idx)=clr{layers}(3);
        clear idx x y
        end
    

   
       tmp(:,:,1)=res1; tmp(:,:,2)=res2;tmp(:,:,3)=res3;
    %  figure,imshow(tmp,[])      

end

