#include <math.h>
#include <matrix.h>
#include <mex.h>

#define pair(i,j,n) pair[(i)+((j)+(n)*thk2)*thk1]
#define tmp(k,n) tmp[(k)+(n)*sz1]

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    
    /* nlhs:no of outputs=1(pair); nrhs=6(base_ht1, base_ht2, tmp, d_mn, d_std,thk)   */
    /*  plhs[0]=> output "pair" */
    /* prhs[0]=base_ht1, prhs[1]=base_ht2, prhs[2]=tmp, prhs[3]=d_mn, prhs[4]=d_std prhs[5]=thk */
    
    /* declare variables for input and output */
    mxArray *pair_out, *base_ht1_in, *base_ht2_in, *tmp_in, *d_mn_in, *d_std_in, *thk_in1,*thk_in2,*b_in, *d_min_in, *d_max_in;
    double *pair, *base_ht1_ptr,*base_ht2_ptr,*tmp,*d_mn,*d_std,*thk_ptr1,*thk_ptr2, *bptr,*d_min,*d_max;
    const mwSize *dims1;
    int dims[3],sz1,sz2;
    double base_ht1, base_ht2,avg,dst, b;
    int n,i,j,ri,rj,k,thk1,thk2;
    
     /* associate inputs */
     base_ht1_in = mxDuplicateArray(prhs[0]);
     base_ht2_in = mxDuplicateArray(prhs[1]);
     tmp_in = mxDuplicateArray(prhs[2]);
     d_mn_in=mxDuplicateArray(prhs[3]);
     d_std_in=mxDuplicateArray(prhs[4]);
     thk_in1=mxDuplicateArray(prhs[5]);
     thk_in2=mxDuplicateArray(prhs[6]);
     
     b_in=mxDuplicateArray(prhs[7]);
     
     d_min_in=mxDuplicateArray(prhs[8]);
     d_max_in=mxDuplicateArray(prhs[9]);
     
     
        /* figure out dimensions */
        dims1 = mxGetDimensions(prhs[2]);
        sz1=(int)dims1[0];
        sz2=(int)dims1[1];
      
        /* get the arrays */
      
        base_ht1_ptr=mxGetPr(base_ht1_in);
        base_ht2_ptr=mxGetPr(base_ht2_in);
        tmp=mxGetPr(tmp_in);
        d_mn=mxGetPr(d_mn_in);
        d_std=mxGetPr(d_std_in);
        thk_ptr1=mxGetPr(thk_in1);
        thk_ptr2=mxGetPr(thk_in2);
        base_ht1=base_ht1_ptr[0];
        base_ht2=base_ht2_ptr[0];
        thk1=(int)thk_ptr1[0];
        thk2=(int)thk_ptr2[0];
        
        bptr=mxGetPr(b_in);
        b=bptr[0];
        
        d_min=mxGetPr(d_min_in);
        d_max=mxGetPr(d_max_in);
     
     /*associate outputs */
    dims[0]=thk1;
    dims[1]=thk2;
    dims[2]=sz2;
     pair_out=plhs[0]=mxCreateNumericArray(3, dims, mxDOUBLE_CLASS,mxREAL);
       pair = mxGetPr(pair_out);
  
     
     
     
     for(n=0;n<sz2;n++)
     {
         /*printf("%lf %lf \n",d_min[n],d_max[n]);*/
         for(i=0;i<thk1;i++)
         {
             for(j=0;j<thk2;j++)
             {
                 ri=i+base_ht1;
                 rj=j+base_ht2;
                
                if((rj-ri)<d_min[n] || (rj-ri)>d_max[n])   
                 {
                    pair(i,j,n)=-999999; 
                 }
                 else
                 {
                     avg=0;
                     for(k=ri; k<=rj;k++)
                     {
                      avg=avg+tmp(k,n);   
                     }
                   /*  dst=sqrt((((rj-ri)-d_mn[n])*((rj-ri)-d_mn[n]))/d_std[n]); */
                   /*  lth1=(exp(- 0.5 * (lth1' - mn(n(idx)) ./ sigma(n(idx))) .^ 2) ./ (sigma(n(idx)) *2* sqrt(2 * pi)))'; */
                    dst=exp(-0.5*pow(((((double)(rj-ri))-d_mn[n])/d_std[n]),2));
                     avg=avg/(rj-ri+1);
                     pair(i,j,n)=avg+b*dst; 
                     
                  /*   printf("\n %lf \t %lf ",avg, dst); */
                 }
    
            }
         }
     }
       
       
   
      
}
