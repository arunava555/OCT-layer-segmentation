function [ mask,gt ] = my_unflatten( img,gt,shift )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


 mask=zeros(size(img));
 for col=1:size(img,2)
      tmp_col=img(:,col);
      sh=shift(col);
      
                                                                    
      tmp_col=circshift(tmp_col,[sh 0]);
      mask(:,col)=tmp_col;
      
     
      
     gt(:,col)=gt(:,col)+sh;
   
   end

end

