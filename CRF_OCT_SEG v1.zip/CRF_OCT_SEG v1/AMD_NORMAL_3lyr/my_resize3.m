function [new_gt2]=my_resize3(gt,sz, img)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


%% Step 1: Resize the ht by multiplying resizing factor
r=sz(1)/size(img,1);
new_gt=gt.*r;
inc=sz(2)/size(gt,2);
%% Step 2:Interpolate 3 pixels in between using B-spline:
new_gt2=zeros(size(gt,1),sz(2));
for l=1:size(gt,1)
   %new_gt(l,:)=spline(gt(l,:),[1:4:sz(2)],[1:sz(2)]); 
   new_gt2(l,:)=interp1([1:inc:sz(2)],new_gt(l,:),[1:sz(2)],'spline');
end
end

