function [res]=reverse_preprocessing(res, bias,img, mnx, mxx,flat_sz ,crop_sz, shift)

load('dflt.mat');
    for l=1:3
        res(l,:)=res(l,:)+dflt_ht(l); 
    end  
     %% STEP1: RESIZE image and gt from [188 600] back to original cropped sz
    res=my_resize3(res,[crop_sz(1) crop_sz(2)],img);
    img=imresize(img,[crop_sz(1) crop_sz(2)],'bicubic');
    %% UNCROP : back to the complete flat image from ROI
        flat_img=zeros(flat_sz);
        flat_img(mnx:mxx,:)=img;
        res=res+mnx;
        
        %% UNFLATTEN back
        [unflat_img, res]=my_unflatten(flat_img,res,shift);
        
         for lyr=1:3
             res(lyr,:)=res(lyr,:)-bias(lyr);
         end
        
    
end

