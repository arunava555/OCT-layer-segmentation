function [d] = my_flatten( img)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

BW=img==255;
[lbl, n]=bwlabel(BW);
for k=1:n
      [tx, ty]=find(lbl==k);
      if min(tx)<15 
          idx=find(lbl==k);
          img(idx)=0;
      end
end
 clear BW lbl n



img1=img;
SIGMA=9;

[mnx, mxx]=my_mask(img);
%% Smooth
 h=fspecial('gaussian',6*SIGMA,SIGMA);
 img=imfilter(img,h,'same','replicate');
 
 %% SOBEL
 BW = edge(img,'Canny');
 
 %% Remove all segments smaller than a particular size
 BW(1:mnx,:)=0;
 BW(mxx:end,:)=0;
 [lbl, n]=bwlabel(BW);
for k=1:n
     idx=find(lbl==k);
     sz(k)=length(idx);
           
end
 sz=sort(sz,'descend');
 th=sz(min(n,3));
 clear sz

 for k=1:n
     idx=find(lbl==k);
     sz=length(idx);
     if sz<th
         
        BW(idx)=0; 
     end       
 end
  [lbl, n]=bwlabel(BW);
% Now for each remaining segment, obtain the possible shift amounts
x=1:size(img,2);
for k=1:n
   [ty, tx]=find(lbl==k);
   P = polyfit(tx,ty,2);
   tmp = round(P(1)*(x.^2)+P(2)*x+P(3));
   y1(k,:)=tmp-min(tmp);
end

 d=round(mode(y1));
 P = polyfit(x,d,2);
 d = round(P(1)*(x.^2)+P(2)*x+P(3));
  d=d-floor(mean(max(d(:), min(d(:)))));
 
end

