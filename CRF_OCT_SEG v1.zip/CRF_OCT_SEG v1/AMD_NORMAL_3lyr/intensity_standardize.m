function [img]=intensity_standardize(img)
standard_percentile=[0    34    51    64    75    87    99   112   129   164   255]';
img=double(img);
img=img-min(img(:));
img=img./max(img(:));
img=img.*255;
img=uint8(img);

h = hist(img(:),0:255);
h= h./sum(h); % convert to PDFs
c= cumsum(h); % calculate CDFs
    
    % Percentile calculation
    for j = 1:10
        percentile_points(j+1) = find(c<(0.1*j),1,'last');   
    end
img =  (round(interp1([percentile_points],standard_percentile,double(img),'liner','extrap')));
    
img=img-min(img(:));
img=img./max(img(:));

end

