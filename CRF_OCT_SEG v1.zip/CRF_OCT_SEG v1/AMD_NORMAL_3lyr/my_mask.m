function [mnx, mxx]=my_mask(img)
%UNTITLED2 Summary of this function goes here

% Remove artifacts: complete 255 connected to top
BW=img==255;
[lbl, n]=bwlabel(BW);
for k=1:n
      [tx, ty]=find(lbl==k);
      if min(tx)<15 
          idx=find(lbl==k);
          img(idx)=0;
      end
end
 clear BW lbl n


img1=img;
SIGMA=9;
%% Smooth
 h=fspecial('gaussian',6*SIGMA,SIGMA);
 img=imfilter(img,h,'same','replicate');
 
 img=img-min(img(:));
 img=img./max(img(:));
 
 % Some modifications for DME image specific
% img=img(75:end-75,:);

 img=img>graythresh(img(100:end-100,:));

% If there are more than 1 connected components then remove any component
% connected to top and bottom
[lbl, n]=bwlabel(img);
if n>1
   for k=1:n
      [tx, ty]=find(lbl==k);
      if min(tx)<15 || max(tx)>=size(img,1)-15
          idx=find(lbl==k);
          img(idx)=0;
      end
   end
end

[tx, ty]=find(img>0);


%mnx=min(tx)-8+74;
%mxx=max(tx)+74;
mnx=min(tx)-12;
mxx=max(tx);


end

