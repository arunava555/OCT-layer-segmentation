mex inter_layer.c
